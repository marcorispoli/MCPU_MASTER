
USB-Com Tools
=============

1. USBVIEW
   (C) Microsoft. Displays all connected USB devices and their 
   properties. Operates also when drivers are not installed.

2. USBCom+_Configurator
   (C) VS Vision Systems GmbH. Searches all Com Ports by the
   USB-COM Plus and ECO series. Allows for easy configuration
   of options for a multitude of serial ports.

3. UsbComCfg
   (C) VS Vision Systems GmbH. Searches for serial ports in
   USB-4COM Plus, -8COM Plus and 16Com Plus models (inclduding
   ISO variants with isolation). Configures operation modes of
   RS232/422/485 via software instead of DIP switches.

